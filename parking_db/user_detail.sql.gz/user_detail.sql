-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2022 at 04:13 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parking_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_detail`
--

CREATE TABLE `user_detail` (
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `role1` int(11) NOT NULL,
  `fullName` varchar(20) NOT NULL,
  `NID` int(11) NOT NULL,
  `Car_Name` varchar(20) NOT NULL,
  `Model` varchar(20) NOT NULL,
  `Registrations_NO` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_detail`
--

INSERT INTO `user_detail` (`username`, `pass`, `phone`, `role1`, `fullName`, `NID`, `Car_Name`, `Model`, `Registrations_NO`) VALUES
('01723265389', '123', '1723265389', 2, 'Fahim Mondol', 87766, '', '', ''),
('car-owner', '123', '1723265389', 2, 'Fahim Mondol', 1234, 'Toyota', ' premio 2011', '23432121322'),
('car_owner2', '123', '1723265389', 2, 'Fahim Mondol', 1234, 'Toyota', ' premio 2011', '23432121322'),
('g-owner', '123', '1723265389', 1, 'Shishir', 0, '', '', ''),
('rrr', '123', '1723265389', 2, 'Fahim Mondol', 1223, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_detail`
--
ALTER TABLE `user_detail`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
